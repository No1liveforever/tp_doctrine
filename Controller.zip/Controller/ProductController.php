<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;

use App\Entity\Product;

class ProductController extends AbstractController
{    
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/products', name: 'product_index')]
    public function index(): Response
    {
        $products = $this->entityManager->getRepository(Product::class)->findAll();

        return $this->render('product/index.html.twig', [
            'products' => $products,
        ]);
    }

    #[Route('/products/new', name: 'product_create')]
    public function create(): Response
    {
        return $this->render('product/create.html.twig');
    }

    #[Route('/products', name: 'product_store', methods: ['POST'])]
    public function store(Request $request): Response
    {
        // Handle form submission to store new product
        $name = $request->request->get('name');
        $price = $request->request->get('price');

        // Example: Create new Product entity and persist it
        $product = new Product();
        $product->setName($name);
        $product->setPrice($price);
        $this->entityManager->persist($product);
        $this->entityManager->flush();

        return $this->redirectToRoute('product_index');
    }

    #[Route('/products/{id}/edit', name: 'product_edit')]
    public function edit(Product $product): Response
    {
        return $this->render('product/edit.html.twig', [
            'product' => $product,
        ]);
    }

    #[Route('/products/{id}', name: 'product_update', methods: ['POST'])]
    public function update(Product $product, Request $request): Response
    {
        // Handle form submission to update existing product
        $name = $request->request->get('name');
        $price = $request->request->get('price');

        // Example: Update Product entity and persist changes
        $product->setName($name);
        $product->setPrice($price);

        $this->entityManager->flush();

        return $this->redirectToRoute('product_index');
    }

    #[Route('/products/{id}', name: 'product_delete', methods: ['DELETE'])]
    public function delete(Product $product): Response
    {
        // Example: Delete Product entity
        $this->entityManager->remove($product);
        $this->entityManager->flush();

        return $this->redirectToRoute('product_index');
    }
}
